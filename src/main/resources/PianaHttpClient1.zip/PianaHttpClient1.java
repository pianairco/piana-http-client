package ir.piana.util.httpclient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ning.http.client.AsyncHttpClient;
import com.ning.http.client.AsyncHttpClient.BoundRequestBuilder;
import com.ning.http.client.Request;
import com.ning.http.client.Response;

import java.io.IOException;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

public class PianaHttpClient1 {
    protected String baseUrl;

    private PianaHttpClient1(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public static PianaHttpClient1 getNewInstance(String baseUrl) {
        return new PianaHttpClient1(baseUrl);
    }

    private void setQueryParams(
            BoundRequestBuilder boundRequestBuilder,
            Map<String, String> queryParams) {
        if(queryParams != null) {
            for (String qpName : queryParams.keySet()) {
                boundRequestBuilder.addQueryParam(qpName, queryParams.get(qpName));
            }
        }
    }

    private void setHeaders(
            BoundRequestBuilder requestBuilder,
            Map<String, Collection<String>> headers) {
        if(headers != null) {
         requestBuilder.setHeaders(headers);
//            for (String header : headers.keySet()) {
//                requestBuilder.addHeader(header, headers.get(header));
//            }
        }
    }

    private void setEntity(
            BoundRequestBuilder boundRequestBuilder,
            Object entity, boolean isUtf8)
            throws JsonProcessingException {
        if(entity != null) {
            if(isUtf8)
                boundRequestBuilder.addHeader("content-type", "application/json;charset=utf-8");
            else
                boundRequestBuilder.addHeader("content-type", "application/json");
            boundRequestBuilder.setBody(new ObjectMapper().writeValueAsString(entity));
        }
    }

    private String createUrl(
            String path, Map<String, String> pathParams) {
        String url = "";
        if(path.contains("{")) {
            url = path.substring(0, path.indexOf("{"));
            String next = path;
            do {
                String pathParamName = next.substring(next.indexOf("{") + 1, next.indexOf("}"));
                String pathParamValue = pathParams.get(pathParamName);
                if(pathParamValue == null)
                    throw new RuntimeException();
                url = url.concat(pathParamValue);
                next = next.substring(next.indexOf("}") + 1);
                if(next.contains("{")) {
                    String beforeCurved = next.substring(0, next.indexOf('{'));
                    url += beforeCurved.isEmpty() ? "/" : beforeCurved;
                }
            } while (next.contains("{"));
            if(url.charAt(url.length() - 1) == '/') {
                url = url.substring(0, url.length() - 1);
            }
            url = url.concat(next);
        } else {
            url = path;
        }
        if(url.charAt(url.length() - 1) == '/') {
            url = url.substring(0, url.lastIndexOf('/'));
        }

        if(baseUrl.charAt(baseUrl.length() - 1) == '/' && url.charAt(0) == '/') {
            baseUrl = baseUrl.substring(0, baseUrl.length() - 1);
        } else if(baseUrl.charAt(baseUrl.length() - 1) != '/' && url.charAt(0) != '/') {
            baseUrl = baseUrl.concat("/");
        }
        return baseUrl.concat(url);
    }

    public final Future<Response> getRequest(
            String path,
            Map<String, String> pathParams,
            Map<String, String> queryParams,
            Map<String, Collection<String>> headers) {
        BoundRequestBuilder boundRequestBuilder = null;
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        boundRequestBuilder = asyncHttpClient
                .prepareGet(createUrl(path, pathParams));
        setQueryParams(boundRequestBuilder, queryParams);
        setHeaders(boundRequestBuilder, headers);

        return boundRequestBuilder
                .execute();
    }

    public final Future<Response> postRequest(
            String path,
            Map<String, String> pathParams,
            Map<String, String> queryParams,
            Map<String, Collection<String>> headers,
            Object entity,
            boolean isUtf8) throws PianaHttpClientException {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        BoundRequestBuilder requestBuilder = asyncHttpClient
                .preparePost(createUrl(path, pathParams));
        setQueryParams(requestBuilder, queryParams);
        setHeaders(requestBuilder, headers);

        try {
            setEntity(requestBuilder, entity, isUtf8);
        } catch (JsonProcessingException e) {
            throw new PianaHttpClientException(e.getMessage());
        }

        Request request = requestBuilder.build();

        return asyncHttpClient.executeRequest(request);
    }

    public final Future<Response> postRequest(
            String path,
            Map<String, String> pathParams,
            Map<String, String> queryParams,
            Map<String, Collection<String>> headers,
            Object entity) throws PianaHttpClientException {
        return postRequest(
                path, pathParams, queryParams, headers, entity, false);
    }

    public final Future<Response> putRequest(
            String path,
            Map<String, String> pathParams,
            Map<String, String> queryParams,
            Map<String, Collection<String>> headers,
            Object entity,
            boolean isUtf8) throws PianaHttpClientException {
        AsyncHttpClient.BoundRequestBuilder boundRequestBuilder = null;
        try {
            AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
            boundRequestBuilder = asyncHttpClient
                    .preparePut(createUrl(path, pathParams));
            setQueryParams(boundRequestBuilder, queryParams);
            setHeaders(boundRequestBuilder, headers);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            setEntity(boundRequestBuilder, entity, isUtf8);
        } catch (JsonProcessingException e) {
            throw new PianaHttpClientException(e.getMessage());
        }
        return boundRequestBuilder
//                .addHeader("Authorization", basic)
                .execute();
    }

    public final Future<Response> putRequest(
            String path,
            Map<String, String> pathParams,
            Map<String, String> queryParams,
            Map<String, Collection<String>> headers,
            Object entity) throws PianaHttpClientException {
        return putRequest(
                path, pathParams, queryParams, headers, entity, false);
    }

    public final Future<Response> deleteRequest(
            String path,
            Map<String, String> pathParams,
            Map<String, String> queryParams,
            Map<String, Collection<String>> headers) {
        AsyncHttpClient.BoundRequestBuilder boundRequestBuilder = null;
        try {
            AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
            boundRequestBuilder = asyncHttpClient
                    .prepareDelete(createUrl(path, pathParams));
            setQueryParams(boundRequestBuilder, queryParams);
            setHeaders(boundRequestBuilder, headers);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return boundRequestBuilder
//                .addHeader("Authorization", basic)
                .execute();
    }

    public Map responseToBodyMap(Response response) {
        Map<String, Object> responseMap = null;
        try {
            responseMap = new ObjectMapper().readValue(
                    response.getResponseBody(), LinkedHashMap.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return responseMap;
    }

    public Map<String, List<String>> responseToHeaderMap(
            Response response) {
        return response.getHeaders();
    }
}
